using System;
using System.Collections.Generic;
using System.Text;

public class TriplesTest
{
    public static void Main(string[] args)
    {
        Triples t = new Triples();
        t.FindTriples();
    
    }
}
