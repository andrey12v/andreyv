namespace Ex13_9
{
    partial class FuzzyDice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBoxRed = new System.Windows.Forms.CheckBox();
            this.checkBoxGreen = new System.Windows.Forms.CheckBox();
            this.checkBoxYellow = new System.Windows.Forms.CheckBox();
            this.textBoxRedQ = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxGreenQ = new System.Windows.Forms.TextBox();
            this.textBoxYellowQ = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxCostRed = new System.Windows.Forms.TextBox();
            this.textBoxCostGreen = new System.Windows.Forms.TextBox();
            this.textBoxCostYellow = new System.Windows.Forms.TextBox();
            this.textBoxSubtotal = new System.Windows.Forms.TextBox();
            this.textBoxTax = new System.Windows.Forms.TextBox();
            this.textBoxshipping = new System.Windows.Forms.TextBox();
            this.textBoxTotal = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.buttonClear = new System.Windows.Forms.Button();
            this.labelShipping = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(101, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of order";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(240, 8);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(145, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "Enter number of order";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Customer\'s name";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(174, 43);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(145, 20);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "Enter customer\'s name";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(174, 75);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(145, 20);
            this.textBox3.TabIndex = 5;
            this.textBox3.Text = "Enter shipping address";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 23);
            this.label3.TabIndex = 4;
            this.label3.Text = "Shipping address";
            // 
            // checkBoxRed
            // 
            this.checkBoxRed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxRed.Location = new System.Drawing.Point(41, 140);
            this.checkBoxRed.Name = "checkBoxRed";
            this.checkBoxRed.Size = new System.Drawing.Size(66, 19);
            this.checkBoxRed.TabIndex = 8;
            this.checkBoxRed.Text = "Red";
            this.checkBoxRed.UseVisualStyleBackColor = true;
            this.checkBoxRed.CheckedChanged += new System.EventHandler(this.checkBoxRed_CheckedChanged);
            // 
            // checkBoxGreen
            // 
            this.checkBoxGreen.AutoSize = true;
            this.checkBoxGreen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxGreen.Location = new System.Drawing.Point(40, 173);
            this.checkBoxGreen.Name = "checkBoxGreen";
            this.checkBoxGreen.Size = new System.Drawing.Size(65, 19);
            this.checkBoxGreen.TabIndex = 9;
            this.checkBoxGreen.Text = "Green";
            this.checkBoxGreen.UseVisualStyleBackColor = true;
            this.checkBoxGreen.CheckedChanged += new System.EventHandler(this.checkBoxGreen_CheckedChanged);
            // 
            // checkBoxYellow
            // 
            this.checkBoxYellow.AutoSize = true;
            this.checkBoxYellow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxYellow.Location = new System.Drawing.Point(40, 210);
            this.checkBoxYellow.Name = "checkBoxYellow";
            this.checkBoxYellow.Size = new System.Drawing.Size(68, 19);
            this.checkBoxYellow.TabIndex = 10;
            this.checkBoxYellow.Text = "Yellow";
            this.checkBoxYellow.UseVisualStyleBackColor = true;
            this.checkBoxYellow.CheckedChanged += new System.EventHandler(this.checkBoxYellow_CheckedChanged);
            // 
            // textBoxRedQ
            // 
            this.textBoxRedQ.Enabled = false;
            this.textBoxRedQ.Location = new System.Drawing.Point(113, 139);
            this.textBoxRedQ.Name = "textBoxRedQ";
            this.textBoxRedQ.Size = new System.Drawing.Size(80, 20);
            this.textBoxRedQ.TabIndex = 11;
            this.textBoxRedQ.Text = "0";
            this.textBoxRedQ.TextChanged += new System.EventHandler(this.textBoxRedQ_TextChanged);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(120, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 23);
            this.label5.TabIndex = 12;
            this.label5.Text = "Quantity";
            // 
            // textBoxGreenQ
            // 
            this.textBoxGreenQ.Enabled = false;
            this.textBoxGreenQ.Location = new System.Drawing.Point(113, 172);
            this.textBoxGreenQ.Name = "textBoxGreenQ";
            this.textBoxGreenQ.Size = new System.Drawing.Size(80, 20);
            this.textBoxGreenQ.TabIndex = 13;
            this.textBoxGreenQ.Text = "0";
            this.textBoxGreenQ.TextChanged += new System.EventHandler(this.textBoxGreenQ_TextChanged);
            // 
            // textBoxYellowQ
            // 
            this.textBoxYellowQ.Enabled = false;
            this.textBoxYellowQ.Location = new System.Drawing.Point(113, 209);
            this.textBoxYellowQ.Name = "textBoxYellowQ";
            this.textBoxYellowQ.Size = new System.Drawing.Size(80, 20);
            this.textBoxYellowQ.TabIndex = 14;
            this.textBoxYellowQ.Text = "0";
            this.textBoxYellowQ.TextChanged += new System.EventHandler(this.textBoxYellowQ_TextChanged);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(207, 113);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 23);
            this.label6.TabIndex = 15;
            this.label6.Text = "Price";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(214, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 23);
            this.label7.TabIndex = 16;
            this.label7.Text = "$5";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(208, 169);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 23);
            this.label8.TabIndex = 17;
            this.label8.Text = "$11";
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(207, 209);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 23);
            this.label9.TabIndex = 18;
            this.label9.Text = "$13";
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(269, 113);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 19);
            this.label10.TabIndex = 20;
            this.label10.Text = "Cost";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(191, 243);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 23);
            this.label11.TabIndex = 24;
            this.label11.Text = "Subtotal";
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(194, 275);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(60, 23);
            this.label12.TabIndex = 26;
            this.label12.Text = "Tax 5%";
            // 
            // textBoxCostRed
            // 
            this.textBoxCostRed.Enabled = false;
            this.textBoxCostRed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCostRed.Location = new System.Drawing.Point(263, 135);
            this.textBoxCostRed.Name = "textBoxCostRed";
            this.textBoxCostRed.Size = new System.Drawing.Size(101, 22);
            this.textBoxCostRed.TabIndex = 27;
            this.textBoxCostRed.Text = "$0";
            // 
            // textBoxCostGreen
            // 
            this.textBoxCostGreen.Enabled = false;
            this.textBoxCostGreen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCostGreen.Location = new System.Drawing.Point(263, 173);
            this.textBoxCostGreen.Name = "textBoxCostGreen";
            this.textBoxCostGreen.Size = new System.Drawing.Size(101, 22);
            this.textBoxCostGreen.TabIndex = 28;
            this.textBoxCostGreen.Text = "$0";
            // 
            // textBoxCostYellow
            // 
            this.textBoxCostYellow.Enabled = false;
            this.textBoxCostYellow.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCostYellow.Location = new System.Drawing.Point(263, 210);
            this.textBoxCostYellow.Name = "textBoxCostYellow";
            this.textBoxCostYellow.Size = new System.Drawing.Size(101, 22);
            this.textBoxCostYellow.TabIndex = 29;
            this.textBoxCostYellow.Text = "$0";
            // 
            // textBoxSubtotal
            // 
            this.textBoxSubtotal.Enabled = false;
            this.textBoxSubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSubtotal.Location = new System.Drawing.Point(263, 242);
            this.textBoxSubtotal.Name = "textBoxSubtotal";
            this.textBoxSubtotal.Size = new System.Drawing.Size(101, 22);
            this.textBoxSubtotal.TabIndex = 30;
            this.textBoxSubtotal.Text = "$0";
            // 
            // textBoxTax
            // 
            this.textBoxTax.Enabled = false;
            this.textBoxTax.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTax.Location = new System.Drawing.Point(263, 276);
            this.textBoxTax.Name = "textBoxTax";
            this.textBoxTax.Size = new System.Drawing.Size(101, 22);
            this.textBoxTax.TabIndex = 31;
            this.textBoxTax.Text = "$0";
            // 
            // textBoxshipping
            // 
            this.textBoxshipping.Enabled = false;
            this.textBoxshipping.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxshipping.Location = new System.Drawing.Point(263, 311);
            this.textBoxshipping.Name = "textBoxshipping";
            this.textBoxshipping.Size = new System.Drawing.Size(101, 22);
            this.textBoxshipping.TabIndex = 32;
            this.textBoxshipping.Text = "$1.50";
            // 
            // textBoxTotal
            // 
            this.textBoxTotal.Enabled = false;
            this.textBoxTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTotal.Location = new System.Drawing.Point(263, 346);
            this.textBoxTotal.Name = "textBoxTotal";
            this.textBoxTotal.Size = new System.Drawing.Size(101, 22);
            this.textBoxTotal.TabIndex = 33;
            this.textBoxTotal.Text = "$0";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(158, 308);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 23);
            this.label13.TabIndex = 35;
            this.label13.Text = "Shipping cost";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(211, 346);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 23);
            this.label14.TabIndex = 36;
            this.label14.Text = "Total";
            // 
            // buttonClear
            // 
            this.buttonClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClear.Location = new System.Drawing.Point(263, 392);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(101, 23);
            this.buttonClear.TabIndex = 37;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // labelShipping
            // 
            this.labelShipping.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelShipping.Location = new System.Drawing.Point(370, 314);
            this.labelShipping.Name = "labelShipping";
            this.labelShipping.Size = new System.Drawing.Size(210, 54);
            this.labelShipping.TabIndex = 38;
            // 
            // FuzzyDice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(602, 477);
            this.Controls.Add(this.labelShipping);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textBoxTotal);
            this.Controls.Add(this.textBoxshipping);
            this.Controls.Add(this.textBoxTax);
            this.Controls.Add(this.textBoxSubtotal);
            this.Controls.Add(this.textBoxCostYellow);
            this.Controls.Add(this.textBoxCostGreen);
            this.Controls.Add(this.textBoxCostRed);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxYellowQ);
            this.Controls.Add(this.textBoxGreenQ);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBoxRedQ);
            this.Controls.Add(this.checkBoxYellow);
            this.Controls.Add(this.checkBoxGreen);
            this.Controls.Add(this.checkBoxRed);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Name = "FuzzyDice";
            this.Text = "Fuzzy Dice";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBoxRed;
        private System.Windows.Forms.CheckBox checkBoxGreen;
        private System.Windows.Forms.CheckBox checkBoxYellow;
        private System.Windows.Forms.TextBox textBoxRedQ;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxGreenQ;
        private System.Windows.Forms.TextBox textBoxYellowQ;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxCostRed;
        private System.Windows.Forms.TextBox textBoxCostGreen;
        private System.Windows.Forms.TextBox textBoxCostYellow;
        private System.Windows.Forms.TextBox textBoxSubtotal;
        private System.Windows.Forms.TextBox textBoxTax;
        private System.Windows.Forms.TextBox textBoxshipping;
        private System.Windows.Forms.TextBox textBoxTotal;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Label labelShipping;
    }
}

