﻿namespace Ex20_3 {
    
    
    public partial class BooksDataSet {
        partial class AuthorsDataTable
        {
        }
    }
}
