        READ ME FILE ON HOW TO USE PROXY SERVER

* The proxy server can request and display the websites that support HTTP protopcol only (not HTTPS) 
  The example websites that can be requested by proxy server are :  www.nutrilookup.com   
  www.w3schools.com   www.tutorialspoint.com  www.ask.com   etc.
 
* First of all, enable proxy setting in your internet browser by setting up localhost: 127.0.0.1 and port number 1234. 

* Run java files �ProxyServer� and "ProxyThread". After you launch the program the message �waiting on the port 1234� will show up in 
  the console screen. 

* After you enter URL a webpage will show up in your internet browser and appropriate records will be made in a proxy log file. 
  The program will also output the records from the log file in the console screen. 

* The proxy log file is created automatically in the folder where the proxy program is executed from  
